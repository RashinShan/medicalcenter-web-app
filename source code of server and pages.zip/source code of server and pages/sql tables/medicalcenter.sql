-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2023 at 04:07 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medicalcenter`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `regno` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`regno`, `name`, `password`) VALUES
('1997', 'admin', '123'),
('admin46', 'admin', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `indexno` varchar(50) NOT NULL,
  `Date` varchar(50) DEFAULT NULL,
  `Time` varchar(50) DEFAULT NULL,
  `discription` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`indexno`, `Date`, `Time`, `discription`) VALUES
('12', '2023-03-30', '14:03', ''),
('2018ICTS12', '2023-04-18', '14:30', ''),
('2018ICTS46', '2023-05-19', '09:38', 'back pain'),
('2018ICTS78', '2023-05-18', '09:43', 'Headache');

-- --------------------------------------------------------

--
-- Table structure for table `doctordetails`
--

CREATE TABLE `doctordetails` (
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Doctornumber` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Age` varchar(50) DEFAULT NULL,
  `UserName` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `PhoneNumber` varchar(50) DEFAULT NULL,
  `CurrentHospitalName` varchar(50) DEFAULT NULL,
  `SpecialistFor` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctordetails`
--

INSERT INTO `doctordetails` (`FirstName`, `LastName`, `Doctornumber`, `Address`, `Age`, `UserName`, `Password`, `Email`, `PhoneNumber`, `CurrentHospitalName`, `SpecialistFor`) VALUES
('kayanan', 'efsdf', '3', '123', 'fsdf', '45', 'kayanan', 'kernal@gmail.com', '0716516444', 'chilaw genaral hospital', 'othopadic'),
('kayanan', 'shan', '123', 'gkgkgkgj@gmail.com', '24', 'rashinshan', '123', 'kamal@gmail.com', '0777671405', 'chilaw genaral hospital', 'othopadic'),
('kayanan', 'shan', '123', 'gkgkgkgj@gmail.com', '24', 'rashinshan', '', 'kamal@gmail.com', '0777671405', 'chilaw genaral hospital', 'othopadic'),
('kayanan', 'shan', 'undefined', 'Thalgahapitiya bingiriya', '27', '122', '123', 'shankumarasinha6@gmail.com', '0772344156', 'undefined', 'othopadic'),
('fssdfs', 'sfdsfsdf', 'undefined', 'dsffsdfsfdsd', 'sdfsfdf', '112233', '123', 'sfsdfsf', 'dfgsdg', 'undefined', 'sgsfgdfg'),
('Rashin', 'ccvvv', 'undefined', 'shankumarasinha6@gmail.com', '27', '2018/ICTS/12sefsf', '123', 'janani@gmail.com', '0772344156', 'undefined', 'zz'),
('Rashinxasx', 'ccvvv', 'undefined', '', '45', 'RashinShansaxasx', '', 'shankumarasinha6@gmail.com', '0743234556', 'undefined', 'othopadic'),
('Rashin', 'ccvvv', '2018ICTS12', 'shankumarasinha6@gmail.com', '27', 'undefined', '123', 'shankumarasinha6@gmail.com', '0772344156', 'undefined', 'zz'),
('pramohd', 'sithara', '33med', 'Thalgahapitiya bingiriya', '27', 'undefined', '123', 'janani@gmail.com', '0772344156', 'undefined', 'zz'),
('Serena', 'Thomas', 'D46', 'chilaw', '34', 'undefined', '81dc9bdb52d04dc20036dbd8313ed055', 'janani@gmail.com', '0772344156', 'undefined', 'Dentist'),
('thavaraja', 'ccvvv', 'D12', 'Thalgahapitiya bingiriya', '45', 'undefined', '202cb962ac59075b964b07152d234b70', 'shankumarasinha6@gmail.com', '0743234556', 'undefined', 'othopadic');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('RashinShan', '123'),
('kanthi', '123'),
('kayanan', '123'),
('Janani', '123'),
('asasf', '123'),
('sxasx', '123'),
('rashinshan', '123'),
('rashinshan', ''),
('RashinShan', '123'),
('RashinShan', '123'),
('kjhjkhjh', '123'),
('janani', '1234'),
('ggfhgf', '123'),
('z', '123'),
('RashinShanerrrrrrr', '123'),
('ergr', '123'),
('supun', '123'),
('akmal', '123'),
('', ''),
('t janani', '123'),
('marcus', '123'),
('vilprat', '123'),
('', ''),
('', ''),
('', ''),
('122', '123'),
('kanthikk', '123'),
('markas', '123'),
('RashinShanrrr44', '123'),
('RashinShanvff', '123'),
('jaan', '123'),
('gghh', '123'),
('2018/ICTS/123', '123'),
('kman', '123'),
('kapila', '123'),
('kamal', '123'),
('saadil', '123'),
('kaakanil', '123'),
('kamalvffg', '123'),
('kokki', '123'),
('RashinShanjj', '123'),
('thfthfhg', '123'),
('fgdfgdfg', '123'),
('2018/ICTS/12ccc', '123'),
('112233', '123'),
('2018/ICTS/12sefsf', '123'),
('RashinShansaxasx', ''),
('undefined', '123'),
('undefined', '123'),
('RashinShan', '81dc9bdb52d04dc20036dbd8313ed055'),
('RashinShan', '202cb962ac59075b964b07152d234b70'),
('Jana', '81dc9bdb52d04dc20036dbd8313ed055'),
('undefined', '81dc9bdb52d04dc20036dbd8313ed055'),
('undefined', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `medicaldetails`
--

CREATE TABLE `medicaldetails` (
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Age` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `birthday` varchar(100) NOT NULL,
  `Weight` varchar(10) DEFAULT NULL,
  `Height` varchar(10) DEFAULT NULL,
  `illness` varchar(100) DEFAULT NULL,
  `bloodgroup` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicaldetails`
--

INSERT INTO `medicaldetails` (`FirstName`, `LastName`, `Age`, `Address`, `birthday`, `Weight`, `Height`, `illness`, `bloodgroup`, `gender`) VALUES
('cxc xc', 'ccvvv', '45', 'bbb', '1999-05-06', '6', '7', 'bcbcvbcbvb', '', ''),
('kayanan', 'lkmnmlkn', '13', 'knl', '1889-02-02', '77', '77', 'khjj', '', ''),
('thavaraja', 'janani', '23', 'hatton', '1999-08-24', '77', '77', 'headache', '', ''),
('', '', '', '', '', '', '', '', '', ''),
('kayanan', 'shan', '45', 'Thalgahapitiya bingiriya', '2023-01-02', '77', '5', '233hederch', 'undefined', 'Male'),
('Rashin', 'efsdf', '45', 'shankumarasinha6@gmail.com', '3320-12-23', '5', '77', 'wqdqwdqwddqwd', 'undefined', 'Male'),
('thavarajh', 'janani', '24', 'Thalgahapitiya bingiriya', '1999-10-08', '77', '5', 'mantel', 'undefined', 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `medicaldetailsdoctors`
--

CREATE TABLE `medicaldetailsdoctors` (
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Age` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `birthday` varchar(100) NOT NULL,
  `Weight` varchar(10) DEFAULT NULL,
  `Height` varchar(10) DEFAULT NULL,
  `illness` varchar(100) DEFAULT NULL,
  `bloodgroup` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `regno` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicaldetailsdoctors`
--

INSERT INTO `medicaldetailsdoctors` (`FirstName`, `LastName`, `Age`, `Address`, `birthday`, `Weight`, `Height`, `illness`, `bloodgroup`, `gender`, `regno`) VALUES
('kayanan', 'shan', '45', 'Thalgahapitiya bingiriya', '1997-05-06', '55', '7', 'madnuss', 'b+', 'Female', ''),
('fsdfsdf', 'sdfsdfsd', '12', 'khljl', '2023-04-22', '77', '7', '233hederch', 'b+', 'undefined', ''),
('Rashin', 'Janani', '45', 'Thalgahapitiya bingiriya', '2023-03-30', '5', '5', 'madnuss', 'b+', 'Female', 'undefined'),
('cxc xc', 'Janani', '45', 'shankumarasinha6@gmail.com', '2023-03-31', '77', '5', '233hederch', 'b-', 'Female', '2018ICTS12'),
('pramotdh', 'sithara', '45', 'shankumarasinha6@gmail.com', '2023-04-06', '', '7', 'mantel', 'b-', 'Male', '33med'),
('Thavaraj', 'Janani', '34', 'chilaw', '2023-05-13', '50KG', '177inches', 'Headache', 'b-', 'Female', 'D46'),
('thavaraja', 'Janani', '', '', '2023-05-24', '5', '5', 'madnuss', 'b+', 'Female', 'D12');

-- --------------------------------------------------------

--
-- Table structure for table `medicaldetailsstaff`
--

CREATE TABLE `medicaldetailsstaff` (
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Age` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `birthday` varchar(100) NOT NULL,
  `Weight` varchar(10) DEFAULT NULL,
  `Height` varchar(10) DEFAULT NULL,
  `illness` varchar(100) DEFAULT NULL,
  `bloodgroup` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `regno` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicaldetailsstaff`
--

INSERT INTO `medicaldetailsstaff` (`FirstName`, `LastName`, `Age`, `Address`, `birthday`, `Weight`, `Height`, `illness`, `bloodgroup`, `gender`, `regno`) VALUES
('vilprat', 'appuhaami', '45', 'Thalgahapitiya bingiriya', '1987-04-07', '77', '7', 'pandi kaachal', 'b+', 'Female', ''),
('kayanan', 'shan', '45', 'Thalgahapitiya bingiriya', '1897-05-06', '77', '7', 'mad', 'b-', 'Female', ''),
('kayanan', 'shan', '27', 'Thalgahapitiya bingiriya', '4444-06-05', '77', '5', 'pandi kaachal', 'b-', 'Male', ''),
('amal', 'desiva', '34', 'Thalgahapitiya bingiriya', '2023-05-06', '55', '44', 'fadsfsdf', 'b+', 'Female', 'undefined'),
('saadilmuusik', 'abdul', '23', 'shankumarasinha6@gmail.com', '2023-04-27', '23', '4', 'mantel', 'b-', 'Female', 'undefined'),
('thavaraja', 'ccvvv', '', 'gkgkgkgj@gmail.com', '2023-03-31', '6', '5', 'mantel', '', 'Female', 'undefined'),
('thavaraja', 'janani', '23', 'chilaw', '2023-04-06', '6', '5', 'wqdqwdqwddqwd', 'b+', 'Female', 'undefined'),
('Rashinasxcacxzx', 'ascas', '13', 'sgrdrg', '2023-04-21', '5', '5555', 'mad', 'b-', 'Female', 'czxc998877');

-- --------------------------------------------------------

--
-- Table structure for table `medicaldetailsstudents`
--

CREATE TABLE `medicaldetailsstudents` (
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Age` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `birthday` varchar(100) NOT NULL,
  `Weight` varchar(10) DEFAULT NULL,
  `Height` varchar(10) DEFAULT NULL,
  `illness` varchar(100) DEFAULT NULL,
  `bloodgroup` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `regno` varchar(100) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicaldetailsstudents`
--

INSERT INTO `medicaldetailsstudents` (`FirstName`, `LastName`, `Age`, `Address`, `birthday`, `Weight`, `Height`, `illness`, `bloodgroup`, `gender`, `regno`, `id`) VALUES
('Rashin', 'shan', '27', 'Thalgahapitiya bingiriya', '1997-02-02', '77', '7', 'madnuss', 'b-', 'Male', '', 1),
('markas', 'deedat', '45', 'Thalgahapitiya bingiriya', '2023-04-05', '77', '5', 'pandi kaachal', 'B-', 'Male', 'undefined', 2),
('Rashin', 'shan', '45', 'shankumarasinha6@gmail.com', '2023-04-05', '77', '4', 'xfbxbxcb', 'b+', 'Male', '2018ICTS127890', 3),
('Thavaraj', 'jaan', '27', 'Thalgahapitiya bingiriya', '2023-04-06', '77', '7', 'madnuss', 'b+', 'Female', '2018ICTS71', 4),
('Thavaraj', 'ccvvv', '27', 'chilaw', '2023-04-28', '77', '7', 'pandi kaachal', 'B-', 'Female', 'uygugvv', 5),
('cxc xc', 'Janani', '27', 'Thalgahapitiya bingiriya', '2023-04-20', '77', '7', 'wqdqwdqwddqwd', 'b-', 'Female', 'dc', 6),
('thavaraja', 'dsfsdf', '24', 'shankumarasinha6@gmail.com', '2023-04-27', '6', '77', '233hederch', 'b+', 'Female', 'dcss', 7),
('kapila', 'amal', '45', 'Thalgahapitiya bingiriya', '2023-04-06', '23', '2', 'sad', 'b-', 'Female', '1212', 8),
('kil', 'shan', '12', 'khljl', '2023-04-04', '5', '5555', 'wqdqwdqwddqwd', 'b+', 'Female', 'shuubal', 9),
('Rashin', 'shan', '27', 'Thalgahapitiya bingiriya', '2023-05-11', '55', '77', 'Backpain', 'b-', 'Female', '2018ICTS46', 10),
('janani', 'thavaraj', '23', 'Hatton', '2023-05-04', '40Kg', '150 inches', 'Headache', 'O+', 'Female', '2018ICTS78', 11);

-- --------------------------------------------------------

--
-- Table structure for table `medicinedetails`
--

CREATE TABLE `medicinedetails` (
  `Name` varchar(50) DEFAULT NULL,
  `Description` varchar(50) DEFAULT NULL,
  `DeliveredDate` varchar(50) DEFAULT NULL,
  `ExpiredDate` varchar(50) DEFAULT NULL,
  `quantity` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicinedetails`
--

INSERT INTO `medicinedetails` (`Name`, `Description`, `DeliveredDate`, `ExpiredDate`, `quantity`) VALUES
(NULL, 'for hedech', '2023/7/5', '2024/7/5', '45'),
('Paracetamol', 'for hedech', '2023/7/5', '2024/7/5', '45');

-- --------------------------------------------------------

--
-- Table structure for table `registerasstaff`
--

CREATE TABLE `registerasstaff` (
  `username` varchar(50) DEFAULT NULL,
  `empNo` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registerasstaff`
--

INSERT INTO `registerasstaff` (`username`, `empNo`, `password`, `email`, `phone`) VALUES
('kanthi', '12', '123', 'kernal@gmail.com', '0716516444'),
('akmal', 'undefined', '123', 'shankumarasinha6@gmail.com', '0743234556'),
('', 'undefined', '', '', ''),
('vilprat', 'undefined', '123', 'kernal@gmail.com', '0777671405'),
('', 'undefined', '', '', ''),
('', 'undefined', '', '', ''),
('', 'undefined', '', '', ''),
('kamal', 'undefined', '123', 'shankumarasinha6@gmail.com', '0772344156'),
('saadil', 'undefined', '123', 'janani@gmail.com', '0772344156'),
('kaakanil', 'undefined', '123', 'janani@gmail.com', '0777671405'),
('kamalvffg', 'undefined', '123', 'kernal@gmail.com', '0712234568'),
('RashinShanjj', '3217', '123', 'janani@gmail.com', '0772344156'),
('thfthfhg', '78', '123', 'shankumarasinha6@gmail.com', '0777671405'),
('2018/ICTS/12ccc', 'czxc998877', '123', 'janani@gmail.com', '0777671405');

-- --------------------------------------------------------

--
-- Table structure for table `registerasstudents`
--

CREATE TABLE `registerasstudents` (
  `username` varchar(50) DEFAULT NULL,
  `regNo` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registerasstudents`
--

INSERT INTO `registerasstudents` (`username`, `regNo`, `password`, `email`, `phone`) VALUES
('kapila', '1212', '123', 'janani@gmail.com', '0743234556'),
('RashinShan', '2018ICTS12', '123', 'shankumarasinha6@gmail.com', '0777671405'),
('RashinShanvff', '2018ICTS127890', '123', 'janani@gmail.com', '0743234556'),
('RashinShan', '2018ICTS46', '202cb962ac59075b964b07152d234b70', 'shankumarasinha6@gmail.com', '0772344156'),
('jaan', '2018ICTS71', '123', 'janani@gmail.com', '0772344156'),
('Jana', '2018ICTS78', '81dc9bdb52d04dc20036dbd8313ed055', 'janani@gmail.com', '0743234556'),
('2018/ICTS/123', 'dc', '123', 'janani@gmail.com', '0772344156'),
('kman', 'dcss', '123', 'shankumarasinha6@gmail.com', '0712234568'),
('fgdfgdfg', 'dfgdfgdfg', '123', 'janani@gmail.com', '0712234568'),
('kokki', 'shuubal', '123', 'janani@gmail.com', '0712234568'),
('markas', 'undefined', '123', 'janani@gmail.com', '0772344156'),
('gghh', 'uygugvv', '123', 'janani@gmail.com', '0712234568'),
('RashinShanrrr44', 'wwwww', '123', 'janani@gmail.com', '0712234568');

-- --------------------------------------------------------

--
-- Table structure for table `staffdetails`
--

CREATE TABLE `staffdetails` (
  `Name` varchar(50) DEFAULT NULL,
  `empNo` varchar(50) DEFAULT NULL,
  `Age` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `PhoneNumber` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `userdetails`
--

CREATE TABLE `userdetails` (
  `IpAddress` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `loginTime` varchar(50) DEFAULT NULL,
  `logoutTime` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`indexno`);

--
-- Indexes for table `medicaldetailsstudents`
--
ALTER TABLE `medicaldetailsstudents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registerasstudents`
--
ALTER TABLE `registerasstudents`
  ADD PRIMARY KEY (`regNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `medicaldetailsstudents`
--
ALTER TABLE `medicaldetailsstudents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
