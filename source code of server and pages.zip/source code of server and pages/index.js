

var con = require('./database');

var express = require("express");
const crypto = require('crypto');

const router = express.Router();
var app = express();

var bodyParser = require('body-parser');
app.use('/', router);
app.use(express.static(__dirname + '/view'));
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
let cookieParser = require('cookie-parser');
app.set('view engine', 'ejs');
app.use(cookieParser());
var regno,regnostff,regnodoc;





//localhost home  page

router.get('/', function (req, res) {
  res.render(__dirname + '/view/homepage'); //
});

router.get('/aboutpage', function (req, res) {
  res.render(__dirname + '/view/aboutpage');//
});

router.get('/comfermpage', function (req, res) {
  res.render(__dirname + '/view/comfermpage');//
});

router.get('/medicaldetailsstaff', function (req, res) {
  res.render(__dirname + '/view/medicaldetailsstaff');//
});

router.get('/medicaldetailsstudents', function (req, res) {
  res.render(__dirname + '/view/medicaldetailsstudents');//
});

router.get('/medicaldetailsdoctor', function (req, res) {
  res.render(__dirname + '/view/medicaldetailsdoctor');//
});


router.get('/admin', function (req, res) {
  var sql = [
    "select * from medicinedetails",
    "select * from appointment",
    "SELECT * FROM medicaldetailsdoctors WHERE regno=?"
  ];
  con.query(sql.join(';'), [regno],  function (error, result) {
    if (error) console.log(error);
   
    res.render(__dirname + "/view/admin", { medicinedetails : result[0],appointment:result[1],medicaldetailsstudents : result[2]});

   
  
  });

  
});

router.get('/homepage', function (req, res) {
  res.render(__dirname + '/view/homepage');//
});

router.get('/appointment', function (req, res) {
  const message = '';

  res.render(__dirname + '/view/appointment',{ message: message });//
 
});


router.get('/contactpage', function (req, res) {
  res.render(__dirname + '/view/contactpage');//
});
router.get('/doctorspage', function (req, res) {
  res.render(__dirname + '/view/doctorspage');//
});
router.get('/doctorregistration', function (req, res) {
  res.render(__dirname + '/view/doctorregistration');//
});
router.get('/studentlogin', function (req, res) {
  res.render(__dirname + '/view/studentlogin');//
});
router.get('/stafflogin', function (req, res) {
  res.render(__dirname + '/view/stafflogin');//
});
router.get('/medicinedetatils', function (req, res) {
  
  res.render(__dirname + '/view/medicinedetatils');//pending
});
router.get('/loginpage', function (req, res) {
  res.render(__dirname + '/view/loginpage');//
});
router.get('/doctorshome', function (req, res) {

  var sql = [
    "select * from medicinedetails",
    "select * from appointment",
    "SELECT * FROM medicaldetailsdoctors WHERE regno=?"
  ];
  con.query(sql.join(';'), [regno],  function (error, result) {
    if (error) console.log(error);
   
    res.render(__dirname + "/view/doctorshome", { medicinedetails : result[0],appointment:result[1],medicaldetailsstudents : result[2]});

});
});




router.get('/studenthome', function (req, res) {
  
 
  var sql1 = "SELECT * FROM medicaldetailsstudents WHERE regno=?";

  con.query(sql1, [regno], function(error, result) {
   
    if (error) throw error;

    res.render(__dirname + '/view/studenthome', { medicaldetailsstudents: result });
  });
});


router.get('/medicaldetails', function (req, res) {
  res.render(__dirname + '/view/medicaldetails');
});

router.get('/staffhome', function (req, res) {
  
  var sql1 = "SELECT * FROM medicaldetailsstaff WHERE regno=?";

  con.query(sql1, [regno], function(error, result) {
    if (error) throw error;

    res.render(__dirname + '/view/staffhome', { medicaldetailsstudents: result });
  });
});




//registration 

app.post('/registrationstudent', function (req, res) {

  var username = req.body.username;
  var registrationnumber = req.body.registrationnumber;
  regno=registrationnumber;
  var password = crypto.createHash('md5').update(req.body.password).digest('hex');
  var email = req.body.email;
  var phonenumber = req.body.phonenumber;


  if (registrationnumber == null || registrationnumber == undefined) {
    // Handle case where registrationnumber is not provided
    res.status(400).send("Registration number is required");
    return;
  }

  res.cookie('registrationnumber', registrationnumber);

  if(username !="" && password!="" && email!="" && phonenumber!=""   ){
    var sql = "INSERT INTO registerasstudents(username,regNo,password,email,phone) VALUES ('" + username + "','" + registrationnumber + "','" + password + "','" + email + "','" + phonenumber + "')";
    var sql2="INSERT INTO login(username,password) VALUES ('" + username + "','" + password + "')";
    con.query(sql, function (error, result) {
      if (error) throw error;

      con.query(sql2, function (error, result) {
        console.log(error);
        if (error) throw error;
        res.redirect("/medicaldetailsstudents");

      });
    });
  }
});



app.post('/registrationstaff', function (req, res) {
 
  var username = req.body.username;
  var employeenumber= req.body.staffno;
  var password = crypto.createHash('md5').update(req.body.password).digest('hex');
  var email = req.body.email;
  var phonenumber = req.body.phonenumber;
  regnostff=employeenumber;
  console.log("from staff reg"+regnostff);
  res.cookie('employeenumber ', employeenumber);
  var sql = "INSERT INTO registerasstaff(username	,empNo	,password	,email,	phone	  )VALUES('" + username + "','" + employeenumber + "','" + password + "','" + email + "','" + phonenumber + "')";
  var sql2="INSERT INTO login(username,password)VALUES('" + username + "','" + password + "')";
  con.query(sql, function (error, result) {
    if (error) throw error;
   
    con.query(sql2, function (error, result) {
      if (error) throw error;
      res.redirect("/medicaldetailsstaff");
  
    });

  });
});




app.post('/registrationdoctor', function (req, res) {
 
  var firstname = req.body.firstname;
  var lastname = req.body.lastname;
  var doctornumber = req.body.regno;
  var password = crypto.createHash('md5').update(req.body.password).digest('hex');
  var address = req.body.address;
  var age = req.body.age;
  var username = req.body.username;
  var email = req.body.email;
  var phonenumber = req.body.phonenumber;
  var hospitalname = req.body.hospitalname;
  var specialist = req.body.specialist;
  regnodoc=doctornumber;
  var sql = "INSERT INTO doctordetails(FirstName,	LastName	,Doctornumber,	Address,	Age,	UserName,	Password,	Email	,PhoneNumber,	CurrentHospitalName	,SpecialistFor)VALUES('" + firstname + "','" + lastname + "','" + doctornumber + "','" + address  + "','" + age + "','" + username + "','" +password + "','" + email + "','" + phonenumber + "','" + hospitalname + "','" + specialist + "')";
  var sql2="INSERT INTO login(username,password)VALUES('" + username + "','" + password + "')";
  con.query(sql, function (error, result) {
    if (error) throw error;
   
    con.query(sql2, function (error, result) {
      if (error) throw error;
      res.redirect("/medicaldetailsdoctor");
  
    });

  });
});


//login

app.post("/login", function (req, res) {
  var regnumber = req.body.regno;
  var password = crypto.createHash('md5').update(req.body.password).digest('hex');

  regno = regnumber;
  var sql1 = "SELECT username FROM doctordetails WHERE Doctornumber = ? AND Password = ?";
  var sql2 = "SELECT username FROM registerasstaff WHERE empNo = ? AND password = ?";
  var sql3 = "SELECT username FROM registerasstudents WHERE regNo = ? AND password = ?";
  var sql4 = "SELECT name FROM admin WHERE regNo = ? AND password = ?";

  con.query(sql1, [regnumber, password], function (error1, result1) {
    if (error1) {
      console.log(error1);
      res.redirect("/");
      return;
    }
    if (result1.length > 0) {
      res.cookie("regno", regno); // Store regno value as a cookie
      res.redirect("/doctorshome");
      return;
    }

    con.query(sql2, [regnumber, password], function (error2, result2) {
      if (error2) {
        console.log(error2);
        res.redirect("/");
        return;
      }
      if (result2.length > 0) {
        res.cookie("regno", regno); // Store regno value as a cookie
        res.redirect("/staffhome");
        return;
      }

      con.query(sql3, [regnumber, password], function (error3, result3) {
        if (error3) {
          console.log(error3);
          res.redirect("/");
          return;
        }
        if (result3.length > 0) {
          res.cookie("regno", regnumber); // Store regno value as a cookie
          res.redirect("/studenthome");
          return;
        }
        con.query(sql4, [regnumber, password], function (error4, result4) {
       
          if (error4) {
            console.log(error4);
            res.redirect("/");
            return;
          }
          if (result4.length > 0) {
            res.cookie("regno", regnumber); // Store regno value as a cookie
            res.redirect("/admin");
            return;
          }
          res.redirect("/");
          return;
        });
      });
    });
  });
}); 

//enter medical details


app.post('/medicaldetailsstudents', function (req, res) {
 
  var firstname = req.body.firstname;
  var lastname = req.body.lastname;
  var address = req.body.address;
  var age = req.body.age;
  var dob = req.body.dob;
  var height = req.body.height;
  var weight = req.body.weight;
  var illness = req.body.illness;
  var boolgroup=req.body.bloodgroup;
  var gender=req.body.checked;

  var registrationnumber = req.cookies.registrationnumber;
 
  var sql = "INSERT INTO medicaldetailsstudents(FirstName,	LastName	,Age,	Address,birthday,	Weight	,Height,	illness,bloodgroup,gender,regno)VALUES('" + firstname + "','" + lastname + "','" +  age + "','" + address + "','" + dob + "','" + weight+ "','" + height + "','" + illness + "','" + boolgroup + "','" + gender + "','" + registrationnumber + "')";
  
  con.query(sql, function (error, result) {
    if (error) throw error;
    res.redirect("/");

  });
});

app.post('/appoinment', function(req, res) {
  const regno = req.cookies.regno;
  var date = req.body.date;
  var time = req.body.time;
var discript=req.body.descrpit;
  var sql1 = "SELECT * FROM appointment WHERE indexno=?";
  var sql2 = "INSERT INTO appointment(indexno, Date, Time,discription) VALUES (?, ?, ?,?)";

  con.query(sql1, [regno], function(error, result) {
    if (error) throw error;
    
    if (result.length > 0) {
      const message = 'you alrady put an appoinment.';
      res.render(__dirname + '/view/appointment',{ message: message });//
    } else {
      con.query(sql2, [regno, date, time,discript], function(error, result) {
        if (error) throw error;

        res.redirect('/appointment');
      });
    }
  });
});

//add medicine details
app.post('/addmed', (req, res) => {
  const name = req.body['medicine-name'];
  const medicineDescription = req.body['medicine-description'];
  const deliveredDate = req.body['DeliveredDate'];
  const expiredDate = req.body['ExpiredDate'];
  const quantity = req.body['quantity'];
  
  var sql1 = "SELECT * FROM medicinedetails WHERE Name=?";
  var sql2 = "INSERT INTO medicinedetails(	Name,Description,	DeliveredDate,	ExpiredDate	,quantity	) VALUES (?, ?, ?,?,?)";

  con.query(sql1, [name], function(error, result) {
    if (error) throw error;
    
    if (result.length > 0) {
      res.send('This medicine alrady added');
    } else {
      con.query(sql2, [name,medicineDescription,deliveredDate,expiredDate,quantity], function(error, result) {
        if (error) throw error;

        res.redirect('/admin');
      });
    }
  });
  
});

//update medicine details


app.post('/upmed', (req, res) => {
  const name = req.body['medicine-name'];
  const medicineDescription = req.body['medicine-description'];
  const deliveredDate = req.body['DeliveredDate'];
  const expiredDate = req.body['ExpiredDate'];
  const quantity = req.body['quantity'];
  
  var sql1 = "UPDATE medicinedetails SET Description = ?, DeliveredDate = ?, ExpiredDate = ?, quantity = ? WHERE Name = ?";

  con.query(sql1, [medicineDescription, deliveredDate, expiredDate, quantity, name], function(error, result) {
    if (error) throw error;

    res.redirect('/admin');
  });
});

//remove medicin

app.post('/removemed', (req, res) => {
  const name = req.body['medicinename'];
  
  
  var sql1 = "DELETE FROM medicinedetails WHERE Name = ?";

  con.query(sql1, [ name], function(error, result) {
    if (error) throw error;

    res.redirect('/admin');
  });
});

app.post('/medicaldetailsstaff', function (req, res) {
 
  var firstname = req.body.firstname;
  var lastname = req.body.lastname;
  var address = req.body.address;
  var age = req.body.age;
  var dob = req.body.dob;
  var height = req.body.height;
  var weight = req.body.weight;
  var illness = req.body.illness;
  var boolgroup=req.body.bloodgroup;
  var gender=req.body.checked;

  var sql = "INSERT INTO medicaldetailsstaff(FirstName,	LastName	,Age,	Address,birthday,	Weight	,Height,	illness,bloodgroup,gender,regno)VALUES('" + firstname + "','" + lastname + "','" +  age + "','" + address + "','" + dob + "','" + weight+ "','" + height + "','" + illness + "','" + boolgroup + "','" + gender + "','" + regnostff+ "')";
  
  con.query(sql, function (error, result) {
    if (error) throw error;
    res.redirect("/");

  });
});

//delete appoinments


app.post('/remappoinmentadmin', (req, res) => {
  const id = req.body['id'];
  
  
  var sql1 = "DELETE FROM appointment WHERE id = ?";

  con.query(sql1, [ id], function(error, result) {
    if (error) throw error;

    res.redirect('/admin');
  });
});

app.post('/remappoinment', (req, res) => {
  const id = req.body['id'];
  
  
  var sql1 = "DELETE FROM appointment WHERE id = ?";

  con.query(sql1, [ id], function(error, result) {
    if (error) throw error;

    res.redirect('/doctorshome');
  });
});

app.post('/medicaldetailsstaff', function (req, res) {
 
  var firstname = req.body.firstname;
  var lastname = req.body.lastname;
  var address = req.body.address;
  var age = req.body.age;
  var dob = req.body.dob;
  var height = req.body.height;
  var weight = req.body.weight;
  var illness = req.body.illness;
  var boolgroup=req.body.bloodgroup;
  var gender=req.body.checked;

  var sql = "INSERT INTO medicaldetailsstaff(FirstName,	LastName	,Age,	Address,birthday,	Weight	,Height,	illness,bloodgroup,gender,regno)VALUES('" + firstname + "','" + lastname + "','" +  age + "','" + address + "','" + dob + "','" + weight+ "','" + height + "','" + illness + "','" + boolgroup + "','" + gender + "','" + regnostff+ "')";
  
  con.query(sql, function (error, result) {
    if (error) throw error;
    res.redirect("/");

  });
});


app.post('/medicaldetailsdoctor', function (req, res) {
 
  var firstname = req.body.firstname;
  var lastname = req.body.lastname;
  var address = req.body.address;
  var age = req.body.age;
  var dob = req.body.dob;
  var height = req.body.height;
  var weight = req.body.weight;
  var illness = req.body.illness;
  var boolgroup=req.body.bloodgroup;
  var gender=req.body.checked;

  var sql = "INSERT INTO medicaldetailsdoctors(FirstName,	LastName	,Age,	Address,birthday,	Weight	,Height,	illness,bloodgroup,gender,regno)VALUES('" + firstname + "','" + lastname + "','" +  age + "','" + address + "','" + dob + "','" + weight+ "','" + height + "','" + illness + "','" + boolgroup + "','" + gender + "','" + regnodoc + "')";
  
  con.query(sql, function (error, result) {
    if (error) throw error;
    res.redirect("/");

  });
});








app.listen(3000);


